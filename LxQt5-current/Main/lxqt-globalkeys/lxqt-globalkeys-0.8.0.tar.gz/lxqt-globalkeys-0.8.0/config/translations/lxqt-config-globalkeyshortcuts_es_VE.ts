<?xml version="1.0" ?><!DOCTYPE TS><TS language="es_VE" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>Encontrar un comando</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>LxQt Shortcut Editor</source>
        <translation>Editor de atajos</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripcion</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Atajo</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Comando</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>Agregar Nuevo</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>Agregar Grupo</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>Nada</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>Nuevo atajo</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>Nuevo Grupo</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>Reiniciar cambios</translation>
    </message>
</context>
</TS>