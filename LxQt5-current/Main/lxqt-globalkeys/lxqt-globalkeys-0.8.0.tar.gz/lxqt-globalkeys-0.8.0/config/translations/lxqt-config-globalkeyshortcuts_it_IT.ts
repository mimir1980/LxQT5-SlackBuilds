<?xml version="1.0" ?><!DOCTYPE TS><TS language="it_IT" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>Trova un comando</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>LxQt Shortcut Editor</source>
        <translation>Editor delle scorciatoie di LxQt</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Scorciatoie</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Comando</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>Aggiungi nuova</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>Aggiungi gruppo</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Azzera</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>Nessuna</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>Aggiungi scorciatoia</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>Nuovo gruppo</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>Azzera le modifiche</translation>
    </message>
</context>
</TS>