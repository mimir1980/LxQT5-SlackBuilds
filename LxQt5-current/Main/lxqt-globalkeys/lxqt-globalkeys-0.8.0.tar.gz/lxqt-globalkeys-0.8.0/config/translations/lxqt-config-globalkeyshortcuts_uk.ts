<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>Знайти команду</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>LxQt Shortcut Editor</source>
        <translation>Редактор скорочень LxQt</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Опис</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Cкорочення</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Команда</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>Додати нове</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Вилучити</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>Додати групу</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Cкинути</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>Нічого</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>Додати скорочення</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Вилучити</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>Нова група</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>Скинути зміни</translation>
    </message>
</context>
</TS>