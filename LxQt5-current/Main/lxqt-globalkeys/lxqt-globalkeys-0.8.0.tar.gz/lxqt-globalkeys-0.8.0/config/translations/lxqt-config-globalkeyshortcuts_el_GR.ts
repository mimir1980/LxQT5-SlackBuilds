<?xml version="1.0" ?><!DOCTYPE TS><TS language="el_GR" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>Εύρεση εντολής</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>LxQt Shortcut Editor</source>
        <translation>Επεξεργασία συντομεύσεων LxQt</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Περιγραφή</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Συντόμευση</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Εντολή</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>Προσθήκη νέας</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Αφαίρεση</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>Προσθήκη ομάδας</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Επαναφορά</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Κλείσιμο</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>Κανένα</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>Προσθήκη συντόμευσης</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Αφαίρεση</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>Νέα ομάδα</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>Επαναφορά αλλαγών</translation>
    </message>
</context>
</TS>