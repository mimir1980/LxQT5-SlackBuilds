<?xml version="1.0" ?><!DOCTYPE TS><TS language="cs_CZ" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>Najít příkaz</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>LxQt Shortcut Editor</source>
        <translation>Editor zkratek</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Popis</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Zkratka</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Příkaz</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>Přidat novou</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>Přidat skupinu</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Vynulovat</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>Žádná</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>Přidat zkratku</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>Nová skupina</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>Vynulovat změny</translation>
    </message>
</context>
</TS>