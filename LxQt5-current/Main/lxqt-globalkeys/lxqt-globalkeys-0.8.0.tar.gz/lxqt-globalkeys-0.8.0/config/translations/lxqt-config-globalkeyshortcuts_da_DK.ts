<?xml version="1.0" ?><!DOCTYPE TS><TS language="da_DK" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>Find en kommando</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>LxQt Shortcut Editor</source>
        <translation>LxQt Tastaturgenveje</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Genvej</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Kommando</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>Tilføj ny</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>Tilføj gruppe</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Nulstil</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Afslut</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>Tilføj genvej</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>Ny gruppe</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>Nulstil ændringer</translation>
    </message>
</context>
</TS>