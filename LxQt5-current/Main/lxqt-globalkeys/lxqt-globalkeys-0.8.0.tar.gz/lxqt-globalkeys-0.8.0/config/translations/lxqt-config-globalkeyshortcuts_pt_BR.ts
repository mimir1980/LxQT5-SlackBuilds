<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_BR" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>Encontrar um comando</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>LxQt Shortcut Editor</source>
        <translation>Editor De Atalhos</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Atalho</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Comando</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>Adicionar Novo</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>Adicionar Grupo</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Redefinir</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>Adicionat Atalho</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>Novo Grupo</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>Redefinir Alterações</translation>
    </message>
</context>
</TS>